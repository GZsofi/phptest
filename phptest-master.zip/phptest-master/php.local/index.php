<?php
	require_once('inc/functions.php');
	require_once('inc/config.php');
	require_once('inc/session.php');
	require_once('inc/page.php');
	require('inc/template.php');
?>
