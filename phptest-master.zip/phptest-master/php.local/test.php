<?php
    $alma = 0;
    for($i = 0; $i < 100; $i++) {
        $alma++;
    };
    echo $alma;
?>